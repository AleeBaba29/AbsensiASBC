<?php

return [

    'enabled' => env('HOOKS_ENABLED', true),

];
