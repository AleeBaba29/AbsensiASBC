<?php

namespace Database\Factories;

use App\Models\AttendeStatus;
use Illuminate\Database\Eloquent\Factories\Factory;

class AttendeStatusFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = AttendeStatus::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
