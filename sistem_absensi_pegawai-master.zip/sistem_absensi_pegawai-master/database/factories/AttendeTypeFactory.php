<?php

namespace Database\Factories;

use App\Models\AttendeType;
use Illuminate\Database\Eloquent\Factories\Factory;

class AttendeTypeFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = AttendeType::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
